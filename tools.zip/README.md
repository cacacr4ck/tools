# cyber-attack-system-1.2.1-Darknime

CMS Exploiter versi opensource CMS exploiter ini penyempurnaan dari versi sebelum nya 

yaitu Project NekoGirl

Name : Cyber Attack System 

Codename : DarkNime

Type : CMS Exploiter

Version : 1.2.1

Username Default : yukinoshita47

Password Default : gsh1337

gunakan di localhost atau di cpanel yang di subdomainkan

#Fitur

__________________________________________

Attack And Exploitation
__________________________________________

Exploit List

CSRF x 1

CSRF x 2

Fatcat SQLI

XSSer

__________________________________________

Vulnerability Scanner And Info Gathering
__________________________________________

Bing IP Grabber

DOM!N@TOR Network Tools

Shellshock Scanner

Web vulnerability scanner

__________________________________________

Tool And Exploiter CMS Lokal
__________________________________________

Lokomedia Auto SQLI

Lokomedia Admin Finder

Popoji CMS Register

__________________________________________

Tool And Exploiter CMS Wordpress
__________________________________________

WP Tevolution Dorker

WP Tevolution Mass Exploit

WP U-Design Mass Exploit

WP NativeChurch LFI Scanner

WP Password Bruteforce

__________________________________________

Tool And Exploiter CMS Joomla
__________________________________________

Joomla Com_User Scanner

Joomla Get Modules Info

Joomla JCE Exploit

__________________________________________

Tool And Exploiter Other CMS
__________________________________________

Magento Add Admin

Auto Plupload

Drupal Core 7 SQLI

Mass Revslider

WHMCMS Auto Exploit

HTTPAttactIIS 

PHP CGI Argument Injection Remote Exploit V0.2 

__________________________________________

Encryption And Hash Cracking
__________________________________________

__________________________________________

Encryption
__________________________________________

Encryption Pack

Base64 En-DEcode

Encoder-Decoder X'Inject

__________________________________________

Hash And Password Crack
__________________________________________

Link HashKiller

MD5 Online

__________________________________________

Tracking And Other Stuff
__________________________________________

Link Whois

Link IP Tracking

Link Shodan HQ

Link 1337 Day

Link Exploit-DB 

__________________________________________

Maintaining Access
__________________________________________

Shell Access Scanner

Pasir Merah Shell Checker
