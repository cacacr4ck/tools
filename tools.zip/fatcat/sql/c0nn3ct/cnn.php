 <?php
  $l = mysql_connect("localhost","root","");
  $y = mysql_select_db("lexcodetech");
  
 ?>