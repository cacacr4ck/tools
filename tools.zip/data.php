<?php
$rootdir = $_SERVER['DOCUMENT_ROOT'];
$site = "http://".$_SERVER['HTTP_HOST'];
$tt = "Mouncyler Community";
$bg = $site."/bground.jpg";
$cmtid = $site;
$lovo = $site."/judul.png";
$titit = $site."/favicon.ico";
$trz = "red";
$bsd = "http://pecobaan.hol.es/kontol.zip";
// ***********************************************************
// ** Bacaan :v                                             **
// ** tt : Judul                                            **
// ** bg : gambar background                                **
// ** cmtid : disarankan jgn dirubah biar bs ngobrol bareng **
// ** lovo : gambar logo                                    **
// ** titit : biarin aja :v                                 **
// ** trz : warna teks yang tadinya hitam                   **
// ** bsd : jangan diganti, buat spam kalo ada yg deface    **
// ***********************************************************
?>
