<?php
//Tampilan Halaman hack.php
include("hack.php");
?>
<html>
<!--Tampilan Iframe-->
<br>
<iframe src="https://www.base64encode.org/" height=400 width=900></iframe>	
</html>

