<?php
$string = $_GET['str'];
echo md5($string);
?>
