<?php
//  __________________________________________________________________________________________
// |                                                                                          |
// |  Made by TheRealDominator                                                                |
// |  Please do not remove any of this tags                                                   |
// |  this code is free to use For everyone as long they don't claim that this is their work  |
// |  thanks For reading this and enjoy my code                                               |
// |__________________________________________________________________________________________|
// 
function AdmUsr (){
// Admin Username (default is Admin)
$AdmUsr = "Admin";
return $AdmUsr;
}

function AdmPwd (){
// Admin Password (default is Admin)
$AdmPwd = "Admin";
return $AdmPwd;
}

function GstUsr (){
// Guest Username (default is Guest)
// To disable the Guest account leave username and password empty
$GstUsr = "Guest";
return $GstUsr;
}

function GstPwd (){
// Guest Password (default is Guest)
$GstPwd = "Guest";
return $GstPwd;
}

function ApiKey (){
// Api Authorization Key (default is akpeiy)
$AuthorizedKey = "akpeiy";
return $AuthorizedKey;
}
?>
