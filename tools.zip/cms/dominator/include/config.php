<?php
//  __________________________________________________________________________________________
// |                                                                                          |
// |  Made by TheRealDominator                                                                |
// |  Please do not remove any of this tags                                                   |
// |  this code is free to use For everyone as long they don't claim that this is their work  |
// |  thanks For reading this and enjoy my code                                               |
// |__________________________________________________________________________________________|
// 
function DisableGuest() {
// Disable Guest Account (default is False)
$DG = false;
return $DG;
}

function DisableLoginWarning() {
// Disable Login Warning (default is False)
$DLW = false;
return $DLW;
}

function DisablePortScan() {
// Disable Port Scanner (default is False)
$DPS = false;
return $DPS;
}

function DisableResolver() {
// Disable DNS Resolver (default is False)
$DDR = false;
return $DDR;
}

function DisableScanner() {
// Disable Vulnerability Scanner (default is False)
$DVS = false;
return $DVS;
}

function DisableStatus() {
// Disable Status Checker (default is False)
$DSC = false;
return $DSC;
}

function DisableHttp() {
//Disable HTTP reader (default is False)
$DHR = false;
return $DHR;
}


function DisableLogs() {
//Disable Logs (default is False)
$DSL = false;
return $DSL;
}

?>
