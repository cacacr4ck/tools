<?php
//Tampilan Halaman hack.php
include("hack.php");
?>

<html>
<!--Tampilan Iframe-->
<br>
<iframe src="adfinder/" height=400 width=900></iframe>	
</html>
